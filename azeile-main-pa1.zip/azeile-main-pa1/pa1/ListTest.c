/***************************************
**** Name: Aaron Zeile *****************
**** CruzID: 2091251 *******************
**** Assignment: pa1 *******************
***************************************/
/****************************************************************************************
*  ListTest.c
*  Test client for List ADT
*****************************************************************************************/
#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include"List.h"

int main(int argc, char* argv[]){
   
	List A = newList();
	//List B = newList();
	
	for (int i = 1; i < 6; i++) {
		append(A, i);
		//append(B, i);
	}
	
	
	// 1, 2, 3, 4, 5
	//FILE *file = fopen("out.txt", "w");
//	printList(file, A);
	//fclose(file);

	printf("list A: \n");
	printList(stdout, A);

//	moveFront(A);
//	moveNext(A);
//	delete(A);
	
	List B = copyList(A);
	printf("new list: \n");
	printList(stdout, B);

//	moveFront(A);	
//	moveNext(A);
//	printf("cursor INDEX: " FORMAT "\n", index(A));
//	printf("cursor DATA: " FORMAT "\n", get(A));
//	moveNext(A);	
	//insertAfter(A, 5);
//	insertBefore(A, 5);
	
	//printf("list B: \n");
	//printList(stdout, B);

	//equals(A,B) ? printf("true!\n") : printf("false!\n");


//	moveFront(A);
//	moveNext(A);

//	printf("expected: 0\nfront index: " FORMAT "\n", index(A));
	
//	printf("cursor: " FORMAT "\n", get(A));
//	prepend(A, 20);	
//	printf("prepended 20\ncursor: " FORMAT "\n", get(A));

//	printList(stdout, A);
//	clear(A);
//	printf("list cleared\n");
//	printf("cursor: " FORMAT "\n", get(A));
	
//	deleteFront(A);
//	printf("deleted front\n");
//	printList(stdout, A);

//	printf("back: " FORMAT "\n", back(A));
	
	//append(A, 20);
	//printf("appended 20\nnew list:\n");
	//printList(stdout, A);

	//moveFront(A);
	//printf("moved to front\n");
	//set(A, 20);
	//printf("changed 5 to 20\n");
	//printList(stdout, A);

	

//	clear(A);
//	printf("cleared\n");
//	append(A, 1);
//	printf("appended 1\n");
//	printList(stdout, A);
	
	//printList(stdout, A);

//	printf("expected: -1, 0, 2, 1\n");

//	printf("undefined index: " FORMAT "\n",  index(A));

//	moveFront(A);	
//	printf("front index: " FORMAT "\n",  index(A));

//	moveNext(A);
//	moveNext(A);
//	printf("next index: " FORMAT "\n",  index(A));
	
//	movePrev(A);
//	printf("previous index: " FORMAT "\n", index(A));
	
	freeList(&A);
	freeList(&B);

   return(0);
}

/*
Output of this program:
1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20
20 19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1
1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20
1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20
false
false
true
1 2 3 4 5 -1 6 7 8 9 11 12 13 14 15 -2 16 17 18 19 20
21
0
*/
